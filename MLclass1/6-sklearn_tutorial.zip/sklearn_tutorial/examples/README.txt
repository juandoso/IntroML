Applications to experiment with scikit-learn tools.
