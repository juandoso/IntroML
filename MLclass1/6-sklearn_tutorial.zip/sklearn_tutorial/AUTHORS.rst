.. -*- mode: rst -*-

People
------

This tutorial is brought to you by the `scikit-learn
<http://scikit-learn.org/>`_ folks, in particular:

.. hlist::

  * `Jake Vanderplas <http://www.astro.washington.edu/vanderplas>`_
  * Olivier Grisel
  * Jaques Grobler
  * `Gael Varoquaux <http://gael-varoquaux.info/blog/>`_

.. _citing:

Citing the scikit-learn
------------------------

A huge amount of work goes in the scikit-learn. Researchers that invest
their time in developing and maintaining the package deserve recognition
with citations. In addition, the Parietal team needs the citations to the
paper in order to justify paying a software engineer on the project. To
garanty the future of the toolkit, if you use it, please cite it.

See the scikit-learn documentation on `how to cite
<http://scikit-learn.org/stable/about.html#citing-scikit-learn>`_.

