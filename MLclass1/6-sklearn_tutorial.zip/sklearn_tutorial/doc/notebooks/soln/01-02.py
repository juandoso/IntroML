# 01-02.py
num0 = i0.sum()
num1 = i1.sum()

prior0 = num0 / float(Ntrain)
prior1 = num1 / float(Ntrain)
