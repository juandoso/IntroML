.. -*- mode: rst -*-

Machine Learning for Astronomical Data Analysis
=================================================

Tutorial on Machine Learning for Astronomical Data Analysis in Python
using the scikit-learn.
